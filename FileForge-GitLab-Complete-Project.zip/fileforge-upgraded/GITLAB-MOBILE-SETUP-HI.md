# FileForge ko sirf mobile se free GitLab par live kaise karein

Aapko laptop, terminal, Node.js, paid hosting ya kharida hua domain nahi chahiye. GitLab Pages free static hosting deta hai. Is project ke liye **GitLab user-site project** banana zaroori hai, taaki website root par chale aur uske links/assets na tootein.

## 1. GitLab account aur project

1. Phone ke Chrome/Safari mein https://gitlab.com kholen aur free account banayein / sign in karein.
2. Apna GitLab username profile mein dekhein (example: `rahul123`).
3. `New project` > `Create blank project` chunein.
4. Project name bilkul apne username ke saath `rahul123.gitlab.io` rakhein. `rahul123` ko apne asli username se replace karein.
5. Visibility `Public` rakhein. `Initialize repository with a README` ko ON kar sakte hain.
6. Project create karein.

Is special project-name se free site address aam taur par `https://rahul123.gitlab.io/` hoga. Apna username use karna hai; example wala nahi.

## 2. Do files repository mein upload karein

Is package ke saath diye `FileForge-GitLab-Mobile-Upload.zip` ko phone ke Downloads mein save karke extract karein. Andar ye do files hongi:

- `.gitlab-ci.yml`
- `fileforge-source.tar.gz`

GitLab project mein:

1. Repository > Files kholen.
2. `+` > `Upload file` chunein.
3. Pehle `fileforge-source.tar.gz` upload karein, commit message `Add FileForge source` rakhein aur commit karein.
4. Phir `.gitlab-ci.yml` upload karein. Agar hidden files nahi dikh rahi hon, phone file manager mein `Show hidden files` enable karein. Commit karein.

Agar GitLab app mein upload option na mile, Chrome menu se `Desktop site` ON karke wahi steps karein.

## 3. Website automatic publish hogi

1. Project mein `Build` > `Pipelines` kholen.
2. Pipeline ko complete hone dein. Pehli baar kuch minute lag sakte hain.
3. Green tick aane ke baad `Deploy` > `Pages` kholen.
4. Wahan dikhne wala `*.gitlab.io` link tap karein.

Har baar source update karne ke baad nayi pipeline automatically chalegi.

## Ads / earning ki sachchai

- Abhi site mein koi fake ad ya khud se earning claim nahi hai.
- Google AdSense approval guaranteed nahi hoti. Google original useful content, policy compliance aur site ownership/verification dekhta hai.
- Google ki URL guidance ke mutabik standard domain chahiye; third-party subdomains par exception sirf uske host-partner flows ke liye hoti hai. GitLab Pages ko host partner maan kar AdSense approval ka promise nahi kiya ja sakta. Isliye free `username.gitlab.io` par AdSense reject ho sakta hai. Official guidance: https://support.google.com/adsense/answer/2784438
- Jab kabhi AdSense approval aur publisher ID mil jaaye, GitLab project > Settings > CI/CD > Variables mein `ADSENSE_CLIENT` naam ka variable banayein aur value `ca-pub-XXXXXXXXXXXXXXXX` rakhein (Google ka exact ID). Phir pipeline rerun karein. Build approved site par AdSense script aur `ads.txt` add karega.
- Ads ke liye privacy/cookie disclosures aur audience-location ke consent rules bhi check karne honge. Apne ads par khud click kabhi na karein.
- GitLab Pages sirf static site host karta hai. Is project ke file tools browser mein chalte hain; server-side conversions/accounts/database included nahi hain.

## Zaroori limitations

- Mobile browser mein bahut bade files process karne par phone ki memory kam pad sakti hai.
- Kuch tools external open-source libraries CDN se load karte hain; unke liye internet chahiye.
- 66 tool routes generate hote hain, lekin har advanced desktop-grade feature jaise OCR, PDF-to-Word layout conversion, HEIC decoding ya PDF password removal available nahi hai.
- GitLab Pages free hosting hai, lekin GitLab ki usage limits aur fair-use rules apply karte hain.

Aapko GitLab account ke alawa kisi paid service ki zaroorat nahi hai. Domain/AdSense ki approval ko alag future step samjhein.

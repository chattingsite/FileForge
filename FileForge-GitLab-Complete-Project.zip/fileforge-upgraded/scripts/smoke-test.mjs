import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve('dist');
const app=fs.readFileSync(path.join(root,'src/app.js'),'utf8');
const slugs=[...app.matchAll(/addTool\('([^']+)'/g)].map(x=>x[1]);
const unique=new Set(slugs);
if(slugs.length<50)throw new Error(`Expected 50+ tools, found ${slugs.length}`);
if(unique.size!==slugs.length)throw new Error('Duplicate tool slugs found.');
for(const slug of slugs){
 const p=path.join(root,'tools',slug,'index.html');
 if(!fs.existsSync(p))throw new Error(`Missing static route: ${slug}`);
 const html=fs.readFileSync(p,'utf8');
 if(!html.includes('<h1>')||!html.includes('rel="canonical"'))throw new Error(`SEO metadata missing: ${slug}`);
}
for(const p of ['index.html','privacy/index.html','terms/index.html','admin/index.html','sitemap.xml','robots.txt'])if(!fs.existsSync(path.join(root,p)))throw new Error(`Missing output: ${p}`);
const sitemap=fs.readFileSync(path.join(root,'sitemap.xml'),'utf8');
if((sitemap.match(/<url>/g)||[]).length!==slugs.length+3)throw new Error('Sitemap route count does not match generated pages.');
console.log(`Smoke test passed: ${slugs.length} unique tools, ${slugs.length} static tool routes, SEO metadata and sitemap present.`);

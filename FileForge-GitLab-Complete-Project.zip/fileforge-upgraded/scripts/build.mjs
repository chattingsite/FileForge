import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const out=path.join(root,'dist');
const siteUrl=(process.env.SITE_URL||process.env.CI_PAGES_URL||'https://example.com').replace(/\/$/,'');
const adsenseClient=(process.env.ADSENSE_CLIENT||'').trim();
fs.rmSync(out,{recursive:true,force:true});fs.mkdirSync(out,{recursive:true});
fs.copyFileSync(path.join(root,'index.html'),path.join(out,'index.html'));
fs.cpSync(path.join(root,'src'),path.join(out,'src'),{recursive:true});
fs.cpSync(path.join(root,'public'),out,{recursive:true});
const js=fs.readFileSync(path.join(root,'src/app.js'),'utf8');
const re=/addTool\('([^']+)','([^']+)','([^']+)','([^']+)'/g;
const tools=[];let m;while((m=re.exec(js))!==null){tools.push({slug:m[1],category:m[2],name:m[3],description:m[4]})}
function page({title,description,url,body,schemaType='WebApplication',category='Utilities'}){
 let html=fs.readFileSync(path.join(root,'index.html'),'utf8');
 html=html.replace(/<title>[\s\S]*?<\/title>/,`<title>${escapeHtml(title)}</title>`)
  .replace(/<meta name="description" content="[^"]*"\s*\/>/,`<meta name="description" content="${escapeAttr(description)}" />`)
  .replace(/<link rel="canonical" href="[^"]*"\s*\/>/,`<link rel="canonical" href="${url}" />`)
  .replace(/<meta property="og:title" content="[^"]*"\s*\/>/,`<meta property="og:title" content="${escapeAttr(title)}" />`)
  .replace(/<meta property="og:description" content="[^"]*"\s*\/>/,`<meta property="og:description" content="${escapeAttr(description)}" />`)
  .replace(/<script type="application\/ld\+json" id="schema">[\s\S]*?<\/script>/,`<script type="application/ld+json" id="schema">${JSON.stringify({'@context':'https://schema.org','@type':schemaType,name:title,description,url,...(schemaType==='WebApplication'?{applicationCategory:category,operatingSystem:'Any'}:{})})}</script>`)
  .replace(/<div id="app" aria-live="polite">[\s\S]*?<\/div>/,`<div id="app" aria-live="polite">${body}</div>`);
 if (adsenseClient && /^ca-pub-[0-9]{16}$/.test(adsenseClient)) {
  html=html.replace('</head>',`<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${adsenseClient}" crossorigin="anonymous"></script>\n</head>`);
 }
 return html;
}
function escapeHtml(s){return String(s).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]))}
function escapeAttr(s){return escapeHtml(s).replace(/"/g,'&quot;')}
const homeBody='<section class="hero"><p class="eyebrow">YOUR FILES. YOUR DEVICE.</p><h1>Everyday file work,<br><span>made effortless.</span></h1><p class="hero-copy">A fast, private toolkit for images, PDFs, spreadsheets and more. No account. No unnecessary uploads.</p></section><noscript>Enable JavaScript to search and use the interactive browser tools.</noscript>';
fs.writeFileSync(path.join(out,'index.html'),page({title:'FileForge — Free Online File Tools',description:'Free, fast and private online tools for images, PDFs, spreadsheets, documents and developers. Process files in your browser.',url:`${siteUrl}/`,body:homeBody,schemaType:'WebSite'}));
for(const t of tools){
 const url=`${siteUrl}/tools/${t.slug}/`;
 const body=`<section class="tool-page"><p class="eyebrow">${escapeHtml(t.category.toUpperCase())} TOOL</p><h1>${escapeHtml(t.name)}</h1><p>${escapeHtml(t.description)}</p><p>Use the interactive ${escapeHtml(t.name)} directly in your browser. Choose your file or enter the data to get started.</p><noscript>JavaScript is required to run this browser-based tool.</noscript></section>`;
 const dir=path.join(out,'tools',t.slug);fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'index.html'),page({title:`${t.name} — Free Online Tool | FileForge`,description:t.description,url,body,category:t.category}));
}
for(const [slug,title,description,body] of [
 ['privacy','Privacy Policy | FileForge','Read how FileForge handles files and browser processing.','<section class="tool-page"><h1>Privacy Policy</h1><p>Files selected in supported tools are processed locally in your browser. FileForge does not upload files to its own server.</p><p>Some tools load third-party libraries from CDNs. Replace this sample policy with a reviewed policy before launch.</p></section>'],
 ['terms','Terms of Use | FileForge','Terms and conditions for using FileForge online tools.','<section class="tool-page"><h1>Terms of Use</h1><p>FileForge is provided as-is. Keep backups of important files and verify generated output before relying on it.</p></section>'],
 ['admin','SEO & Analytics Dashboard | FileForge','Local site health and SEO checklist for FileForge administrators.','<section class="tool-page"><h1>SEO & Analytics Dashboard</h1><p>Local site-health dashboard. JavaScript is required to display browser-local metrics.</p></section>']
]){const dir=path.join(out,slug);fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'index.html'),page({title,description,url:`${siteUrl}/${slug}/`,body,schemaType:'WebPage'}));}
const urls=[`${siteUrl}/`,...tools.map(t=>`${siteUrl}/tools/${t.slug}/`),`${siteUrl}/privacy/`,`${siteUrl}/terms/`];
fs.writeFileSync(path.join(out,'sitemap.xml'),`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map(u=>`  <url><loc>${u}</loc></url>`).join('\n')}\n</urlset>\n`);
fs.writeFileSync(path.join(out,'robots.txt'),`User-agent: *\nAllow: /\nDisallow: /admin/\nSitemap: ${siteUrl}/sitemap.xml\n`);
if (adsenseClient && /^ca-pub-[0-9]{16}$/.test(adsenseClient)) {
 const publisherId=adsenseClient.replace(/^ca-/, '');
 fs.writeFileSync(path.join(out,'ads.txt'),`google.com, ${publisherId}, DIRECT, f08c47fec0942fa0\n`);
}
console.log(`Built ${tools.length} tool routes in ${out}`);
console.log(`Production URL: ${siteUrl}${siteUrl.includes('example.com')?' (set SITE_URL/CI_PAGES_URL before launch)':''}`);
console.log(`AdSense: ${adsenseClient && /^ca-pub-[0-9]{16}$/.test(adsenseClient) ? 'script injected' : 'not configured (no ads shown)'}`);

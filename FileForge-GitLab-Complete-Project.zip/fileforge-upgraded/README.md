# FileForge 2.0 — Browser-first file toolkit

A lightweight, static, privacy-first website built with vanilla JavaScript and CSS. No application server or database is required for the included tools. Tool pages are generated as individual static routes with unique titles, descriptions, canonical URLs and structured metadata.

## Included

- 66 browser-based tools across Image, PDF, Spreadsheet, Documents, Text, Developer and Calculator categories.
- Global search, category filters, favorites and recently used tools.
- Batch image conversion/resizing/compression/grayscale with ZIP downloads; PDF splitting and PDF-to-image ZIP exports.
- Local-only tool-open counts in `/admin/` plus a site SEO checklist. This is **not** site-wide visitor analytics.
- Individual static routes under `/tools/<tool-slug>/`, `sitemap.xml`, `robots.txt`, privacy and terms pages.
- Responsive layout, keyboard search shortcut (`/`), dark/light theme, accessible labels and focus styles.
- Vercel and Netlify static deployment configuration.

## Run locally

Requires Node.js 18+.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

## Build for production

Set your actual public website domain before building. Do not leave `example.com` in production metadata.

```bash
SITE_URL=https://your-domain.com npm run build
```

On Windows PowerShell:

```powershell
$env:SITE_URL="https://your-domain.com"; npm run build
```

The generated static site is in `dist/`. To preview it locally, run `npm run dev` or serve `dist/` with any static HTTP server. The build script itself uses Node built-ins and does not require a framework build step.

## Deploy to Vercel

1. Push this folder to a Git repository.
2. Import the repository in Vercel.
3. Set Build Command to `npm run build` and Output Directory to `dist`.
4. Set `SITE_URL` to your production domain in the project's environment variables.
5. Deploy, then submit `https://your-domain.com/sitemap.xml` in Google Search Console.

## Deploy to Netlify

1. Import the repository in Netlify.
2. Build command: `npm run build`.
3. Publish directory: `dist`.
4. Add `SITE_URL` as an environment variable and deploy.

## Important production notes

- **No fake upload backend:** included file operations run in the browser. Optional PDF, spreadsheet, ZIP and DOCX libraries are fetched from public CDNs when needed. A network connection is required the first time a library is loaded.
- **No global analytics yet:** `/admin/` displays browser-local tool-open counts and a launch checklist. Connect GA4/Plausible/Matomo and Google Search Console separately for real site-wide analytics; update the privacy policy and consent flow as required.
- **PDF limitations:** PDF-to-Word with layout fidelity, OCR, password removal, strong PDF encryption/password protection, and full vector/text editing are not included. The basic PDF optimizer re-saves the document and may not reduce size. Browser-only libraries do not provide reliable parity with desktop PDF editors.
- **Image limitations:** HEIC decoding depends on browser support and is not promised. Animated GIF input is rendered as a bitmap frame by the browser canvas pipeline; animation is not preserved when exporting.
- **Document limitations:** DOCX-to-text extracts plain text; formatting, tables and layout are not retained. Text-to-DOCX creates a simple editable document.
- **Security:** do not upload highly sensitive files to any website unless you have reviewed its implementation and hosting configuration. Keep dependency versions updated and consider self-hosting pinned CDN libraries for stricter supply-chain control.
- Replace `hello@example.com`, sample privacy/terms copy, `SITE_URL`, and the social metadata before launch.
- Test with representative large files and target browsers. Browser memory limits vary; this project intentionally does not claim unlimited file-size support.

## Tool count

The registry is the source of truth in `src/app.js`. The build script generates one SEO-friendly static HTML route for each `addTool(...)` entry.

# FileForge 2.0 — GitLab Pages edition

This edition is packaged for deployment from a phone using GitLab's web interface. No local Node.js, terminal, paid hosting, or purchased domain is needed.

## Deployment shape

Create a **user-site project** named exactly `<your-gitlab-username>.gitlab.io`. This is important because the current app uses root-relative URLs. The project will publish to `https://<your-gitlab-username>.gitlab.io/`.

Upload these two root-level files from `FileForge-GitLab-Mobile-Upload.zip`:

- `.gitlab-ci.yml`
- `fileforge-source.tar.gz`

The pipeline unpacks the source archive, builds the static site using Node.js built-ins (no npm install needed), runs the smoke test, and publishes `dist/` through GitLab Pages.

See `GITLAB-MOBILE-SETUP-HI.md` for phone-only steps.

## Optional AdSense

No ad code is enabled by default. After a real AdSense approval, set a GitLab CI/CD variable named `ADSENSE_CLIENT` to the exact `ca-pub-XXXXXXXXXXXXXXXX` publisher ID. The build injects the official AdSense loader and writes `ads.txt`. A GitLab Pages `gitlab.io` subdomain may not qualify under Google's standard-domain requirements; approval is never guaranteed.
